from django.apps import AppConfig


class RoadanomalyverificationConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "RoadAnomalyVerification"
