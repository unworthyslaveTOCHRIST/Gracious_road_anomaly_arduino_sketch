from django.contrib import admin

# Register your models here.

from .models import RoadAnomalyVerification

admin.site.register(RoadAnomalyVerification)