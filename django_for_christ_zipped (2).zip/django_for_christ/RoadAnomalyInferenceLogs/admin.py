# ALL THANKS AND GLORY TO THE AND my ONLY GOD AND LORD JESUS CHRIST ALONE

from django.contrib import admin

# Register your models here.

from .models import RoadAnomalyInferenceLogs
admin.site.register(RoadAnomalyInferenceLogs)
