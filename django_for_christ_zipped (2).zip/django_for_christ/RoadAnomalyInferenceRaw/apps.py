from django.apps import AppConfig


class RoadanomalyinferencerawConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "RoadAnomalyInferenceRaw"
